package Chatbox;

import java.io.File;
import java.io.FileOutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.function.Consumer;

public class UdpFileReceiver {

    private boolean running = false;
    private DatagramSocket socket;

    public void start(int port, String saveFolder, Consumer<String> onLog) {
        if (running) return;
        running = true;

        Thread thread = new Thread(() -> {
            FileOutputStream fos = null;
            String currentFileName = null;

            try {
                socket = new DatagramSocket(port);
                byte[] buffer = new byte[65507];

                if (onLog != null) {
                    onLog.accept("UDP Receiver đang lắng nghe ở cổng " + port);
                }

                while (running) {
                    DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
                    socket.receive(packet);

                    String msg = new String(packet.getData(), 0, packet.getLength(), StandardCharsets.UTF_8);

                    if (msg.startsWith("FILE|")) {
                        String[] parts = msg.split("\\|", 3);
                        currentFileName = parts[1];

                        File dir = new File(saveFolder);
                        if (!dir.exists()) dir.mkdirs();

                        File outFile = new File(dir, currentFileName);
                        fos = new FileOutputStream(outFile);

                        if (onLog != null) {
                            onLog.accept("Đang nhận file: " + currentFileName);
                        }
                    } else if (msg.startsWith("DATA|")) {
                        if (fos == null) continue;

                        String[] parts = msg.split("\\|", 3);
                        byte[] data = Base64.getDecoder().decode(parts[2]);
                        fos.write(data);
                    } else if ("END".equals(msg)) {
                        if (fos != null) {
                            fos.close();
                            fos = null;
                        }

                        if (onLog != null && currentFileName != null) {
                            onLog.accept("Nhận xong file: " + currentFileName);
                        }

                        currentFileName = null;
                    }
                }
            } catch (Exception e) {
                if (running && onLog != null) {
                    onLog.accept("Lỗi UDP Receiver: " + e.getMessage());
                }
            } finally {
                try {
                    if (fos != null) fos.close();
                } catch (Exception ignored) {
                }
            }
        });

        thread.setDaemon(true);
        thread.start();
    }

    public void stop() {
        running = false;
        try {
            if (socket != null) socket.close();
        } catch (Exception ignored) {
        }
    }
}